<?php
include 'sql_connect.php';
session_start();

$pengguna_id = $_POST['pengguna_id'];
$posting = $_POST['discussion'];
$tag = $_POST['tag'];
$jenis = $_POST['jenis'];
$today = date('Y-m-d');
$id_admin = $_SESSION['id'];

$sql = "INSERT INTO discussion(id, tag, posting, user_id, jenis, tanggal) VALUES ('','$tag','$posting','1','$jenis','$today')";

if (mysqli_query($conn, $sql)) {
    header('Location: discussion.php?id=5');
    exit;
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
