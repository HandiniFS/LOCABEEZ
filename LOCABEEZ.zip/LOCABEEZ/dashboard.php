<?php include 'sql_connect.php';
session_start();
if ($_SESSION['status'] != "login") {
  header("location:login/login.php?pesan=belum_login");
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Dashboard</title>
  <link rel="stylesheet" href="styles.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
</head>

<body>
  <div class="sidebar" id="sidebar">
    <?php include "sidebar.php" ?>
  </div>
  <div class="main-content" id="main-content">
    <div class="header">
      <h2>Dashboard</h2>
      <div class="search-profile">
        <input type="text" placeholder="Search here..." />
      </div>
      <div class="profile">
        <img src="handini.png" alt="Profile Picture" />
        <span>Handini</span>
      </div>
    </div>
    <section class="dashboard">
      <div class="summary">
        <h2>Today's Situation</h2>
        <p>UMKM Summary</p>

        <div class="summary-content">
          <?php
          $data = mysqli_query($conn, "SELECT count(umkm_id) as umkm FROM umkm_data");
          while ($d = mysqli_fetch_array($data)) {
          ?>
            <div class="summary-item total-umkm">
              <h3><?php echo $d['umkm'] ?></h3>
              <p>Total UMKM</p>
              <span>+8% from yesterday</span>
            </div>
          <?php } ?>
          <div class="summary-item average-growth">
            <h3>20%</h3>
            <p>Average growth rate</p>
            <span>+1% from yesterday</span>
          </div>
        </div>
      </div>
      <div class="card post">
        <h1 class="main-title">Top Topic Discussion</h1>
        <div class="topics">
          <?php
          $data = mysqli_query($conn, "SELECT * FROM discussion GROUP BY tag LIMIT 3");
          while ($d = mysqli_fetch_array($data)) {
          ?>
            <a class="topic">#<?php echo $d['tag'] ?></a>
          <?php } ?>
          <a href="discussion.php?id=5" class="view-all">View all Topic</a>
        </div>
      </div>
      <div class="charts">
        <div class="card top-performing">
          <h3>TOP Performing UMKMs</h3>
          <canvas id="topPerformingChart"></canvas>
        </div>
        <div class="card top-performing">
          <h3>LOW Performing UMKMs</h3>
          <canvas id="lowPerformingChart"></canvas>
        </div>
      </div>
      <div class="charts">
        <div class="card growth-rate">
          <h3>Laju Pertumbuhan UMKM</h3>
          <canvas id="growthRateChart"></canvas>
        </div>
        <div class="card tasks">
          <h3>Notes</h3>
          <?php
          $data = mysqli_query($conn, "SELECT * FROM notes LIMIT 3");
          while ($d = mysqli_fetch_array($data)) {
          ?>
            <div class="task-list">
              <p><strong><?php echo $d['nama_kegiatan'] ?></strong></p>
              <p><?php echo $d['time'] ?></p>
            </div>
          <?php } ?>
          <a href="notes.php?id=4">View all Tasks</a>
        </div>
      </div>


    </section>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script>
    <?php
    $sum_p = mysqli_query($conn, "select umkm_data.nama_usaha as nama_usaha, pendapatan.umkm_id, sum(pendapatan) as pendapatan from pendapatan, umkm_data WHERE pendapatan.umkm_id=umkm_data.umkm_id GROUP BY umkm_id ORDER BY umkm_id desc LIMIT 5");
    while ($sum_d = mysqli_fetch_array($sum_p)) {
      $umkm_id[] = $sum_d["nama_usaha"];
      $pendapatan[] = $sum_d["pendapatan"];
    }
    ?>
    if (document.getElementById("topPerformingChart")) {
      const ctxTopPerforming = document
        .getElementById("topPerformingChart")
        .getContext("2d");
      const topPerformingChart = new Chart(ctxTopPerforming, {
        type: "bar",
        data: {
          <?php  ?>
          labels: <?php echo json_encode($umkm_id) ?>,
          datasets: [{
            label: "Pendapatan UMKM",
            data: <?php echo json_encode($pendapatan) ?>,
            backgroundColor: "rgba(54, 162, 235, 0.2)",
            borderColor: "rgba(54, 162, 235, 1)",
            borderWidth: 1,
          }, ],
        },

        options: {
          scales: {
            y: {
              beginAtZero: false,
            },
          },
        },
      });
    }

    <?php
    $sum_p2 = mysqli_query($conn, "select umkm_data.nama_usaha as nama_usaha, pendapatan.umkm_id, sum(pendapatan) as pendapatan from pendapatan, umkm_data WHERE pendapatan.umkm_id=umkm_data.umkm_id GROUP BY umkm_id ORDER BY umkm_id asc LIMIT 3");
    while ($sum_d2 = mysqli_fetch_array($sum_p2)) {
      $umkm_id2[] = $sum_d2["nama_usaha"];
      $pendapatan2[] = $sum_d2["pendapatan"];
    }
    ?>
    if (document.getElementById("lowPerformingChart")) {
      const ctxLowPerforming = document
        .getElementById("lowPerformingChart")
        .getContext("2d");
      const lowPerformingChart = new Chart(ctxLowPerforming, {
        type: "bar",
        data: {
          <?php  ?>
          labels: <?php echo json_encode($umkm_id2) ?>,
          datasets: [{
            label: "Pendapatan UMKM",
            data: <?php echo json_encode($pendapatan2) ?>,
            backgroundColor: "rgba(54, 162, 235, 0.2)",
            borderColor: "rgba(54, 162, 235, 1)",
            borderWidth: 1,
          }, ],
        },

        options: {
          scales: {
            y: {
              beginAtZero: false,
            },
          },
        },
      });
    }

    <?php
    $sum_p1 = mysqli_query($conn, "SELECT bulan, tahun, sum(pendapatan) as pendapatan FROM pendapatan WHERE tahun=2022 GROUP BY bulan ORDER BY id");
    while ($sum_d1 = mysqli_fetch_array($sum_p1)) {
      $bulan[] = $sum_d1["bulan"];
      $pendapatan1[] = $sum_d1["pendapatan"];
    }

    $sum_p2 = mysqli_query($conn, "SELECT bulan, tahun, sum(pendapatan) as pendapatan FROM pendapatan WHERE tahun=2023 GROUP BY bulan ORDER BY id");
    while ($sum_d2 = mysqli_fetch_array($sum_p2)) {
      $pendapatan2[] = $sum_d2["pendapatan"];
    }
    ?>

    if (document.getElementById("growthRateChart")) {
      const ctxGrowth = document.getElementById("growthRateChart").getContext("2d");
      const growthRateChart = new Chart(ctxGrowth, {
        type: "line",
        data: {
          labels: <?php echo json_encode($bulan) ?>,
          datasets: [{
              label: "2022",
              data: <?php echo json_encode($pendapatan1) ?>,
              borderColor: "rgba(75, 192, 192, 1)",
              borderWidth: 2,
              fill: false,
            },
            {
              label: "2023",
              data: <?php echo json_encode($pendapatan2) ?>,
              borderColor: "rgba(153, 102, 255, 1)",
              borderWidth: 2,
              fill: false,
            },
          ],
        },
        options: {
          scales: {
            y: {
              beginAtZero: false,
            },
          },
        },
      });
    }
  </script>
</body>

</html>