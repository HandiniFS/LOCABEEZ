// Initialize Popular Training Topics Chart (UMKM Development Page)
if (document.getElementById("popularTrainingChart")) {
  const ctxPopularTraining = document
    .getElementById("popularTrainingChart")
    .getContext("2d");
  const popularTrainingChart = new Chart(ctxPopularTraining, {
    type: "doughnut",
    data: {
      labels: ["Topic A", "Topic B", "Topic C", "Topic D"],
      datasets: [
        {
          data: [10, 20, 30, 40],
          backgroundColor: ["#FF6384", "#36A2EB", "#FFCE56", "#4BC0C0"],
          hoverBackgroundColor: ["#FF6384", "#36A2EB", "#FFCE56", "#4BC0C0"],
        },
      ],
    },
  });
}

// Initialize Training Participation Chart (UMKM Development Page)
if (document.getElementById("trainingParticipationChart")) {
  const ctxTrainingParticipation = document
    .getElementById("trainingParticipationChart")
    .getContext("2d");
  const trainingParticipationChart = new Chart(ctxTrainingParticipation, {
    type: "bar",
    data: {
      labels: ["January", "February", "March", "April", "May", "June"],
      datasets: [
        {
          label: "Participation",
          data: [12, 19, 3, 5, 2, 3],
          backgroundColor: "rgba(75, 192, 192, 0.2)",
          borderColor: "rgba(75, 192, 192, 1)",
          borderWidth: 1,
        },
      ],
    },
    options: {
      scales: {
        y: {
          beginAtZero: true,
        },
      },
    },
  });
}


  // Initialize Top Performing UMKM Chart (Dashboard & UMKM Development Pages)
  if (document.getElementById("topPerformingChart")) {
    const ctxTopPerforming = document
      .getElementById("topPerformingChart")
      .getContext("2d");
    const topPerformingChart = new Chart(ctxTopPerforming, {
      type: "bar",
      data: {
        labels: ["UMKM C", "UMKM B", "UMKM A", "UMKM E", "UMKM D"],
        datasets: [
          {
            label: "Sales",
            data: [14000, 12000, 8000, 10000, 6000],
            backgroundColor: "rgba(54, 162, 235, 0.2)",
            borderColor: "rgba(54, 162, 235, 1)",
            borderWidth: 1,
          },
        ],
      },
      options: {
        scales: {
          y: {
            beginAtZero: true,
          },
        },
      },
    });
  }

// Initialize Growth Rate Chart (Dashboard & UMKM Development Pages)
if (document.getElementById("growthRateChart")) {
  const ctxGrowth = document.getElementById("growthRateChart").getContext("2d");
  const growthRateChart = new Chart(ctxGrowth, {
    type: "line",
    data: {
      labels: ["January", "February", "March", "April", "May"],
      datasets: [
        {
          label: "2023",
          data: [573, 620, 675, 710, 750],
          borderColor: "rgba(75, 192, 192, 1)",
          borderWidth: 2,
          fill: false,
        },
        {
          label: "2024",
          data: [790, 830, 860, 920, 1000],
          borderColor: "rgba(153, 102, 255, 1)",
          borderWidth: 2,
          fill: false,
        },
      ],
    },
    options: {
      scales: {
        y: {
          beginAtZero: true,
        },
      },
    },
  });
}

// Initialize Performance Summary Chart
if (document.getElementById("performanceSummaryChart")) {
  const ctxPerformanceSummary = document
    .getElementById("performanceSummaryChart")
    .getContext("2d");
  const performanceSummaryChart = new Chart(ctxPerformanceSummary, {
    type: "line",
    data: {
      labels: ["January", "February", "March", "April", "May"],
      datasets: [
        {
          label: "2023",
          data: [573, 620, 675, 710, 750],
          borderColor: "rgba(75, 192, 192, 1)",
          borderWidth: 2,
          fill: false,
        },
      ],
    },
    options: {
      scales: {
        y: {
          beginAtZero: true,
        },
      },
    },
  });
}

// Initialize Monthly Performance Chart
if (document.getElementById("monthlyPerformanceChart")) {
  const ctxMonthlyPerformance = document
    .getElementById("monthlyPerformanceChart")
    .getContext("2d");
  const monthlyPerformanceChart = new Chart(ctxMonthlyPerformance, {
    type: "bar",
    data: {
      labels: ["January", "February", "March", "April", "May", "June"],
      datasets: [
        {
          label: "Monthly Performance",
          data: [12, 19, 3, 5, 2, 3],
          backgroundColor: "rgba(75, 192, 192, 0.2)",
          borderColor: "rgba(75, 192, 192, 1)",
          borderWidth: 1,
        },
      ],
    },
    options: {
      scales: {
        y: {
          beginAtZero: true,
        },
      },
    },
  });
}

// Initialize Annual Growth Chart
if (document.getElementById("annualGrowthChart")) {
  const ctxAnnualGrowth = document
    .getElementById("annualGrowthChart")
    .getContext("2d");
  const annualGrowthChart = new Chart(ctxAnnualGrowth, {
    type: "line",
    data: {
      labels: ["January", "February", "March", "April", "May"],
      datasets: [
        {
          label: "2023",
          data: [573, 620, 675, 710, 750],
          borderColor: "rgba(75, 192, 192, 1)",
          borderWidth: 2,
          fill: false,
        },
        {
          label: "2024",
          data: [790, 830, 860, 920, 1000],
          borderColor: "rgba(153, 102, 255, 1)",
          borderWidth: 2,
          fill: false,
        },
      ],
    },
    options: {
      scales: {
        y: {
          beginAtZero: true,
        },
      },
    },
  });

  //top topic on dashboard
  const topics = document.querySelectorAll(".topic");

  topics.forEach((topic) => {
    topic.addEventListener("click", (event) => {
      event.preventDefault();
      console.log("Clicked on topic:", topic.textContent);
    });
  });

  //Learning Module on UMKM Development
  function openPage(pageName, elmnt, color) {
    // Hide all elements with class="tabcontent" by default */
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }

    // Remove the background color of all tablinks/buttons
    tablinks = document.getElementsByClassName("tablink");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].style.backgroundColor = "";
    }

    // Show the specific tab content
    document.getElementById(pageName).style.display = "block";

    // Add the specific color to the button used to open the tab content
    elmnt.style.backgroundColor = color;
  }

  // Get the element with id="defaultOpen" and click on it
  document.getElementById("defaultOpen").click();

  //performance
  document.addEventListener("DOMContentLoaded", function () {
    // Data untuk grafik
    const monthlyData = {
      labels: [
        "Jan",
        "Feb",
        "Mar",
        "Apr",
        "May",
        "Jun",
        "Jul",
        "Aug",
        "Sep",
        "Oct",
        "Nov",
        "Dec",
      ],
      datasets: [
        {
          label: "Pendapatan Bulanan",
          data: [
            4000000, 5000000, 6000000, 7000000, 8000000, 9000000, 10000000,
            11000000, 12000000, 13000000, 14000000, 15000000,
          ],
          backgroundColor: "rgba(54, 162, 235, 0.2)",
          borderColor: "rgba(54, 162, 235, 1)",
          borderWidth: 1,
        },
      ],
    };

    const yearlyData = {
      labels: ["2023", "2024"],
      datasets: [
        {
          label: "Pertumbuhan Tahunan",
          data: [600000000, 720000000],
          backgroundColor: "rgba(75, 192, 192, 0.2)",
          borderColor: "rgba(75, 192, 192, 1)",
          borderWidth: 1,
        },
      ],
    };

    // Grafik pendapatan bulanan
    const monthlyCtx = document
      .getElementById("monthly-performance-chart")
      .getContext("2d");
    new Chart(monthlyCtx, {
      type: "bar",
      data: monthlyData,
      options: {
        scales: {
          y: {
            beginAtZero: true,
          },
        },
      },
    });

    // Grafik pertumbuhan tahunan
    const yearlyCtx = document
      .getElementById("yearly-growth-chart")
      .getContext("2d");
    new Chart(yearlyCtx, {
      type: "line",
      data: yearlyData,
      options: {
        scales: {
          y: {
            beginAtZero: true,
          },
        },
      },
    });
  });

  // script.js
  document.addEventListener("DOMContentLoaded", () => {
    console.log("Halaman siap!");
  });
}
