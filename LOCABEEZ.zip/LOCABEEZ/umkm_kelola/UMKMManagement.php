<?php include '../sql_connect.php';
session_start();
if ($_SESSION['status'] != "login") {
  header("location:../login/login.php?pesan=belum_login");
} ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>User Management</title>
  <link rel="stylesheet" href="../styles.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
</head>

<body>
  <div class="sidebar">
    <?php include "sidebar.php" ?>
  </div>
  <div class="main-content">
    <header>
      <div class="header">
        <h2>UMKM Management</h2>
        <div class="search-profile">
          <input type="text" placeholder="Search here...">
        </div>
        <div class="profile">
          <img src="../handini.png" alt="Profile Picture">
          <span>Handini</span>
        </div>
      </div>
    </header>
    <section class="user-management">
      <div class="request-section">
        <h3>Permintaan mendaftar</h3>
        <?php
        $batas1 = 3;
        $halaman1 = isset($_GET['halaman1']) ? (int)$_GET['halaman1'] : 1;
        $halaman_awal1 = ($halaman1 > 1) ? ($halaman1 * $batas1) - $batas1 : 0;

        $previous1 = $halaman1 - 1;
        $next1 = $halaman1 + 1;

        $data1 = mysqli_query($conn, "select * FROM umkm_data where verifikasi = 0 ");
        $jumlah_data1 = mysqli_num_rows($data1);
        $total_halaman1 = ceil($jumlah_data1 / $batas1);

        $data_umkm = mysqli_query($conn, "select * from umkm_data where verifikasi = 0 limit $halaman_awal1, $batas1");
        $nomor1 = $halaman_awal1 + 1;
        while ($d = mysqli_fetch_array($data_umkm)) { ?>
          <div class="request-card">
            <p><?php echo ucwords(strtolower($d['nama_usaha'])) ?></p>
            <div class="approve-box">
              <button class="reject-button" onclick="rejectUMKM(<?php echo $d['umkm_id'] ?>)">reject</button>
              <button class="approve-button" onclick="document.getElementById('approve-<?php echo $d['umkm_id'] ?>').style.display='block'">Approve</button>
            </div>
          </div>
        <?php
        }
        ?>
        <div class="page_1">
          <a <?php if ($halaman1 > 1) {
                echo "href='?id=3&halaman1=$previous1'";
              } ?>>&laquo;</a>
          <?php
          for ($x1 = 1; $x1 <= $total_halaman1; $x1++) {
          ?>
            <a <?php if ($x1 == $halaman1) {
                  echo "class='active'";
                } ?> href="?id=3&halaman1=<?php echo $x1 ?>"><?php echo $x1; ?></a>
          <?php
          }
          ?>
          <a <?php if ($halaman1 < $total_halaman1) {
                echo "href='?id=3&halaman1=$next1'";
              } ?>>&raquo;</a>
        </div>
      </div>
      <div class="registered-businesses">
        <h3>Bisnis Terdaftar</h3>
        <div class="search-bar">
          <input type="text" placeholder="Search by Name, Email" />
        </div>
        <table>
          <thead>
            <tr>
              <th><input type="checkbox" /></th>
              <th>Nama Usaha</th>
              <th>Jenis Usaha </th>
              <th>Tahun Berdiri </th>
              <th>Kontak Bisnis</th>
              <th>Pemilik</th>
              <th>Tindakan</th>
            </tr>
          </thead>
          <tbody>

            <?php
            $batas = 10;
            $halaman = isset($_GET['halaman']) ? (int)$_GET['halaman'] : 1;
            $halaman_awal = ($halaman > 1) ? ($halaman * $batas) - $batas : 0;

            $previous = $halaman - 1;
            $next = $halaman + 1;


            $no = 1;
            $data = mysqli_query($conn, "select * FROM umkm_data where verifikasi = 1 ");
            $jumlah_data = mysqli_num_rows($data);
            $total_halaman = ceil($jumlah_data / $batas);

            $data_umkm = mysqli_query($conn, "select * from umkm_data where verifikasi = 1 limit $halaman_awal, $batas");
            $nomor = $halaman_awal + 1;
            while ($d = mysqli_fetch_array($data_umkm)) {
            ?>
              <tr>
                <td><input type="checkbox" /></td>
                <td><?php echo $d['nama_usaha']; ?></td>
                <td><?php echo $d['jenis_usaha']; ?></td>
                <td><?php echo $d['tahun']; ?></td>
                <td><?php echo $d['kontak_bisnis']; ?> </td>
                <td><?php echo ucwords(strtolower($d['nama_pengusaha'])); ?></td>
                <td class="aksi">
                  <a href="performance.php?id=<?php echo $d['umkm_id']; ?>" class="edit-button"><i class="fa-regular fa-pen-to-square"></i></a><button onclick="deleteUMKM(<?php echo $d['umkm_id'] ?>)" class="delete-button"><i class="fa-solid fa-trash"></i></button>
                </td>
              </tr>

            <?php

            }
            ?>
          </tbody>
        </table>
        <br>
        <div class="page_1">
          <a <?php if ($halaman > 1) {
                echo "href='?id=3&halaman=$previous'";
              } ?>>&laquo;</a>
          <?php
          for ($x = 1; $x <= $total_halaman; $x++) {
          ?>
            <a <?php if ($x == $halaman) {
                  echo "class='active'";
                } ?> href="?id=3&halaman=<?php echo $x ?>"><?php echo $x; ?></a>
          <?php
          }
          ?>
          <a <?php if ($halaman < $total_halaman) {
                echo "href='?id=3&halaman=$next'";
              } ?>>&raquo;</a>
        </div>

      </div>
      <?php
      $data_umkm = mysqli_query($conn, "select * from umkm_data where verifikasi = 0");
      while ($d = mysqli_fetch_array($data_umkm)) { ?>
        <div id="approve-<?php echo $d['umkm_id'] ?>" class="modal">
          <span onclick="document.getElementById('approve-<?php echo $d['umkm_id'] ?>').style.display='none'" class="close" title="Close Modal">&times;</span>
          <form method="post" action="approve.php">
            <div class="modal-content">
              <h2>UMKM Verification</h2>
              <hr />
              <input hidden name="id" value="<?php echo $d['umkm_id']; ?>" />

              <div class="form-group">
                <label for="nama-usaha">Nama Usaha</label>
                <input hidden type="text" name="nama-usaha" value="<?php echo $d['nama_usaha']; ?>" />
              </div>
              <div class="form-group">
                <label for="nama_pengusaha">Pemilik</label>
                <input hidden type="text" name="nama_pegusaha" value="<?php echo $d['nama_pengusaha']; ?>" />
              </div>
              <div class="form-group">
                <label for="jenis_usaha">Jenis Usaha</label>
                <input hidden type="text" name="jenis_usaha" value="<?php echo $d['jenis_usaha']; ?>" />
              </div>
              <div class="form-group">
                <label for="tahun">Tahun berdiri Usaha</label>
                <input hidden type="text" name="tahun" value="<?php echo $d['tahun']; ?>" />
              </div>
              <div class="form-group">
                <label for="kontak_bisnis">Kontak Bisnis</label>
                <input hidden type="text" name="kontak_bisnis" value="<?php echo $d['kontak_bisnis']; ?>" />
              </div>
              <div class="form-group">
                <label for="email_bisnis">Email Bisnis</label>
                <input hidden type="text" name="email_bisnis" value="<?php echo $d['email_bisnis']; ?>" />
              </div>
              <div class="form-group">
                <label for="alamat_usaha">Alamat Usaha</label>
                <input hidden type="text" name="alamat_usaha" value="<?php echo $d['alamat_usaha']; ?>" />
              </div>


              <div class="clearfix">
                <button type="button" onclick="document.getElementById('approve-<?php echo $d['umkm_id'] ?>').style.display='none'" class="button cancelbtn">
                  Cancel
                </button>
                <button type="submit" class="signupbtn">Approve</button>
              </div>
            </div>
          </form>
        </div>
      <?php
      }
      ?>
    </section>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script src="scripts.js"></script>
  <script>
    function deleteUMKM(id) {
      if (confirm("Apakah Anda yakin ingin menghapus data UMKM ini?")) {
        window.location.href = "delete_umkm.php?id=" + id;
      }
    }

    function rejectUMKM(id) {
      if (confirm("Apakah Anda yakin ingin menolak usulan data UMKM ini?")) {
        window.location.href = "delete_umkm.php?id=" + id;
      }
    }
  </script>
</body>

</html>