<?php
include '../sql_connect.php';

session_start();

$umkm_id = $_POST['id'];
$nama_usaha = $_POST['nama-usaha'];
$today = date('d-m-Y  H:i:s');
$id_admin = $_SESSION['id'];

if (mysqli_query($conn, "update umkm_data set verifikasi=1 where umkm_id=$umkm_id")) {
    $update_query = "UPDATE user_management SET histori_admin ='Approving UMKM: $nama_usaha pada $today' WHERE id=$id_admin";
    if (mysqli_query($conn, $update_query)) {

        $sql_log = "INSERT INTO log_admin (admin_id, action, timestamp)
        VALUES ('$id_admin', 'Menambahkan admin baru', '$today')";
        if (mysqli_query($conn, $sql_log)) {
            header('Location: UMKMmanagement.php?id=3');
            exit;
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
