<?php include '../sql_connect.php';
session_start();
if ($_SESSION['status'] != "login") {
  header("location:../login/login.php?pesan=belum_login");
} ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Dashboard</title>
  <link rel="stylesheet" href="../styles.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
</head>

<body>
  <div class="sidebar" id="sidebar">
    <?php include "sidebar.php" ?>
  </div>
  <div class="main-content" id="main-content">
    <header>
      <div class="header">
        <h2>Performance</h2>
        <div class="search-profile">
          <input type="text" placeholder="Search here..." />
        </div>
        <div class="profile">
          <img src="../handini.png" alt="Profile Picture" />
          <span>Handini</span>
        </div>
      </div>
    </header>

    <h1 class="main-title">Performance Summary</h1>
    <div class="row">
      <div class="column left">
        <div class="card">
          <div class="section" id="identitas-usaha">
            <?php
            $id = $_GET['id'];
            $data = mysqli_query($conn, "select * from umkm_data where umkm_id='$id'");
            while ($d = mysqli_fetch_array($data)) {
            ?>
              <h2>Identitas Usaha</h2>
              <div class="column-desc">
                <p class="column-1"><strong>Nama Usaha:</strong></p>
                <p class="column-2" id="nama-bisnis"><?php echo $d['nama_usaha'] ?></p>
              </div>
              <div class="column-desc">
                <p class="column-1"><strong>Deskripsi Usaha:</strong></p>
                <p class="column-2" id="deskripsi-bisnis">
                  <?php //echo $d['deskripsi_usaha'] 
                  ?>
                </p>
              </div>
              <div class="column-desc">
                <p class="column-1"><strong>Alamat Usaha:</strong></p>
                <p class="column-2" id="alamat-usaha"><?php echo $d['alamat_usaha'] ?></p>
              </div>
              <div class="column-desc">
                <p class="column-1"><strong>jenis Usaha:</strong></p>
                <p class="column-2" id="jenis-usaha"><?php echo $d['jenis_usaha'] ?></p>
              </div>
              <div class="column-desc">
                <p class="column-1"><strong>Nomor Izin Usaha:</strong></p>
                <p class="column-2" id="nomor-usaha"><?php //echo $d['nomor_izin'] 
                                                      ?></p>
              </div>
          </div>

          <div class="section" id="data-pemilik">
            <h2>Data Pemilik</h2>
            <div class="column-desc">
              <p class="column-1"><strong>Nama Pemilik:</strong></p>
              <p class="column-2" id="nama-pemilik"><?php echo $d['nama_pengusaha'] ?></p>
            </div>
            <div class="column-desc">
              <p class="column-1"><strong>Kontak Bisnis:</strong></p>
              <p class="column-2" id="kontak-bisnis"><?php echo $d['kontak_bisnis'] ?></p>
            </div>
            <div class="column-desc">
              <p class="column-1"><strong>Email Bisnis:</strong></p>
              <p class="column-2" id="email-bisnis"><?php echo $d['email_bisnis'] ?></p>
            </div>
            <div class="section" id="aspek-hukum">
              <h2>Aspek Hukum</h2>
              <div class="column-desc">
                <p class="column-1"><strong>Status Hukum Usaha:</strong></p>
                <p class="column-2" id="status-hukum"><?php //echo $d['status_hukum'] 
                                                      ?></p>
              </div>
              <div class="column-desc">
                <p class="column-1"><strong>NPWP:</strong></p>
                <p class="column-2" id="npwp"><?php //echo $d['npwp'] 
                                              ?></p>
              </div>
            </div>
          </div>
        <?php
            }
        ?>
        <div class="section" id="data-keuangan">
          <h2>Data Keuangan</h2>

          <table>
            <thead>
              <tr>
                <th>Bulan</th>
                <th>Tahun</th>
                <th>Pemasukan</th>
              </tr>
            </thead>
            <tbody>
              <?php
              $id = $_GET['id'];

              $data_p = mysqli_query($conn, "select * from pendapatan where umkm_id='$id'");
              while ($d = mysqli_fetch_array($data_p)) {
              ?>
                <tr>
                  <td><?php echo $d['bulan'] ?></td>
                  <td><?php echo $d['tahun'] ?></td>
                  <td><?php echo "Rp." . number_format($d['pendapatan'], 2, ',', '.') ?></td>
                </tr>
              <?php
              }
              ?>
            </tbody>
            <tfoot>
              <?php
              $sum_p = mysqli_query($conn, "select sum(pendapatan) as pendapatan from pendapatan where umkm_id='$id'");
              while ($sum_d = mysqli_fetch_array($sum_p)) { ?>
                <tr>
                  <th colspan="2">Total</th>
                  <th><?php echo "Rp." . number_format($sum_d['pendapatan'], 2, ',', '.') ?></th>
                </tr>
              <?php
              }
              ?>
            </tfoot>
          </table>

        </div>
        </div>
      </div>
      <div class="column right">
        <div class="card top-performing">
          <h3>TOP Performing UMKMs</h3>
          <canvas id="topPerformingChart"></canvas>
        </div>
        <div class="card growth-rate" style="margin-top: 20px">
          <h3>Laju Pertumbuhan UMKM</h3>
          <canvas id="growthRateChart"></canvas>
        </div>
      </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="../scripts.js"></script>
  </div>
</body>

</html>