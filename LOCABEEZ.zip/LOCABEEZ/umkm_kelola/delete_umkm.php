<?php
include '../sql_connect.php';
session_start();

$umkmId = mysqli_real_escape_string($conn, $_GET['id']);
$id_admin = $_SESSION['id'];
$today = date('d-m-Y  H:i:s');

if (empty($umkmId)) {
    http_response_code(400); // Bad Request
    echo json_encode(array("message" => "ID UMKM tidak ditemukan."));
    exit;
}

$sqlDelete = "DELETE FROM umkm_data WHERE umkm_id = '$umkmId'";

if (mysqli_query($conn, $sqlDelete)) {
    $sqlUpdateHistory = "UPDATE user_management 
                         SET histori_admin = 'Menghapus UMKM dengan ID: $umkmId'
                         WHERE id = $id_admin";
    mysqli_query($conn, $sqlUpdateHistory);

    $sql_log = "INSERT INTO log_admin (admin_id, action, timestamp)
    VALUES ('$id_admin', 'Mengedit data notes', '$today')";
    mysqli_query($conn, $sql_log);

    http_response_code(200);
    echo json_encode(array("message" => "UMKM berhasil dihapus."));
    header("Location: UMKMManagement.php?id=3");
} else {
    http_response_code(500);
    echo json_encode(array("message" => "Gagal menghapus UMKM."));
    header("Location: UMKMManagement.php?id=3");
}

mysqli_close($conn);
