<?php include 'sql_connect.php';
session_start();
if ($_SESSION['status'] != "login") {
  header("location:../login/login.php?pesan=belum_login");
} ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notes</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<body>
    <div class="sidebar" id="sidebar">
        <?php include "sidebar.php" ?>
    </div>
    <div class="main-content" id="main-content">
        <div class="header">
            <h2>Settings</h2>
            <div class="search-profile">
                <input type="text" placeholder="Search here...">
            </div>
            <div class="profile">
                <img src="handini.png" alt="Profile Picture">
                <span>Handini</span>
            </div>
        </div>
        </section>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="scripts.js"></script>
</body>

</html>