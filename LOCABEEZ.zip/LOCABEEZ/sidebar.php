<div class="logo">
    <img src="Grafik.png" alt="Logo" class="logo-img">
    <h1><span class="loca">LOCA</span><span class="beez">BEEZ</span></h1>
</div>
<nav>
    <ul>
        <li><a href="dashboard.php?id=1" <?php if ($_GET['id'] == 1) {
                                                echo "class='active'";
                                            } ?>><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
        <li><a href="UMKMDevelopment.php?id=2" <?php if ($_GET['id'] == 2) {
                                                    echo "class='active'";
                                                } ?>><i class="fa-solid fa-shop"></i> UMKM Development</a></li>
        <li><a href="umkm_kelola/UMKMManagement.php?id=3" <?php if ($_GET['id'] == 3) {
                                                                echo "class='active'";
                                                            } ?>><i class="fa-regular fa-folder-open"></i> UMKM Management</a></li>
        <li><a href="Notes.php?id=4" <?php if ($_GET['id'] == 4) {
                                            echo "class='active'";
                                        } ?>><i class="fa-regular fa-calendar-check"></i> Notes</a></li>
        <li><a href="discussion.php?id=5" <?php if ($_GET['id'] == 5) {
                                                echo "class='active'";
                                            } ?>><i class="fa-solid fa-people-arrows"></i> UMKM Discussion</a></li>
        <li><a href="AI_Recomendation.php?id=6" <?php if ($_GET['id'] == 6) {
                                                    echo "class='active'";
                                                } ?>><i class="fa-regular fa-lightbulb"></i>AI Recomendation</a></li>
        <?php if ($_SESSION['role'] == 'super admin') { ?>
            <li><a href="UserManagement.php?id=7" <?php if ($_GET['id'] == 7) {
                                                        echo "class='active'";
                                                    } ?>><i class="fas fa-users"></i> User Management</a></li>
        <?php } ?> <li><a href="Settings.php?id=8" <?php if ($_GET['id'] == 8) {
                                                        echo "class='active'";
                                                    } ?>><i class="fas fa-cogs"></i> Settings</a></li>
        <li><a href="logout.php?id=9" <?php if ($_GET['id'] == 9) {
                                            echo "class='active'";
                                        } ?>><i class="fas fa-sign-out-alt"></i> Sign Out</a></li>
    </ul>
</nav>