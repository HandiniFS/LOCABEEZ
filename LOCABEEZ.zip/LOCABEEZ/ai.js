document.addEventListener("DOMContentLoaded", () => {
    const chatForm = document.querySelector(".chat-form");
  
    chatForm.addEventListener("submit", async (event) => {
        event.preventDefault();
  
        const input = document.getElementById('chat-input');
        const message = input.value.trim();
  
        if (message) {
            addUserMessage(message);
            input.value = '';
  
            try {
                const response = await fetch('AI_Recomendation.php?id=6', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: new URLSearchParams({ user_input: message })
                });
  
                if (response.ok) {
                    const text = await response.text();
                    addBotMessage(text);
                } else {
                    addBotMessage("Sorry, something went wrong. Please try again.");
                }
            } catch (error) {
                console.error('Error:', error);
                addBotMessage("Sorry, something went wrong. Please try again.");
            }
        }
    });
  
    function addUserMessage(message) {
        const chatMessages = document.getElementById('chat-messages');
        const userMessage = document.createElement('div');
        userMessage.className = 'chat-message user-message';
        userMessage.innerHTML = `<p>${message}</p>`;
        chatMessages.appendChild(userMessage);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
  
    function addBotMessage(message) {
        const chatMessages = document.getElementById('chat-messages');
        const botMessage = document.createElement('div');
        botMessage.className = 'chat-message bot-message';
        botMessage.innerHTML = `<p>${message}</p>`;
        chatMessages.appendChild(botMessage);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
  });
  