<?php include 'sql_connect.php';
session_start();
if ($_SESSION['status'] != "login") {
    header("location:login/login.php?pesan=belum_login");
} ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Discussion</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<body>
    <div class="sidebar" id="sidebar">
        <?php include "sidebar.php" ?>
    </div>
    <div class="main-content" id="main-content">
        <div class="header">
            <h2>Discussion</h2>
            <div class="search-profile">
                <input type="text" placeholder="Search here...">
            </div>
            <div class="profile">
                <img src="handini.png" alt="Profile Picture">
                <span>Handini</span>
            </div>
        </div>
        <div class="request-section">
            <form method="post" action="add_diss.php">
                <h3>What's up!</h3>
                <input type="hidden" name="jenis" value="0" />
                <div class="row-modal">
                    <label class="col-1" for="tag"><b>Topic</b></label>
                    <input class="col-2" type="text" name="tag" />
                </div>
                <div class="form-group">
                    <textarea class="textarea" rows="5" type="text" name="discussion">Write something here..</textarea>
                </div>

                <div class="clearfix">
                    <button class="approve-button" type="submit">Add</button>
                </div>
            </form>
        </div>
        <div class="request-section">
            <h3>UMKM Discussion Post</h3>
            <?php
            $data = mysqli_query($conn, "select * from discussion where jenis=0");
            while ($d = mysqli_fetch_array($data)) {
            ?>
                <div class="request-section">
                    <h3>#<?php echo $d['tag'] ?></h3>
                    <div class="container-diss">
                        <img src="handini.png" alt="Avatar" style="width:100%;">
                        <p><?php echo $d['posting'] ?></p>
                        <span class="time-right"><?php echo $d['tanggal'] ?></span>
                    </div>
                    <button type="button" class="collapsible"><i class="fa-regular fa-comment"></i></button>

                    <div class="content-reply">
                        <?php
                        $tag = $d['tag'];
                        $data1 = mysqli_query($conn, "select * from discussion where jenis=1 and tag='$tag'");
                        while ($d1 = mysqli_fetch_array($data1)) {
                        ?>
                            <div class="container-diss darker">
                                <img src="handini.png" alt="Avatar" class="right" style="width:100%;">
                                <p><?php echo $d1['posting'] ?></p>
                                <span class="time-left"><?php echo $d1['tanggal'] ?></span>
                            </div>
                        <?php } ?>
                    </div>

                    <form method="post" action="add_diss.php">
                        <input type="hidden" name="jenis" value="1" />
                        <input class="col-2" type="hidden" name="tag" value="<?php echo $d['tag'] ?>" />
                        <div class="form-group">
                            <textarea class="reply" rows="5" type="text" name="discussion">Reply here..</textarea>
                        </div>

                        <div class="clearfix">
                            <button class="approve-button" type="submit">Add</button>
                        </div>
                    </form>
                </div>
            <?php } ?>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="scripts.js"></script>
    <script>
        var coll = document.getElementsByClassName("collapsible");
        var i;

        for (i = 0; i < coll.length; i++) {
            coll[i].addEventListener("click", function() {
                this.classList.toggle("active");
                var content = this.nextElementSibling;
                if (content.style.display === "block") {
                    content.style.display = "none";
                } else {
                    content.style.display = "block";
                }
            });
        }
    </script>
</body>

</html>