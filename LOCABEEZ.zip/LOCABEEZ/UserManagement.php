<?php include 'sql_connect.php';
session_start();
if ($_SESSION['status'] != "login") {
    header("location:login/login.php?pesan=belum_login");
}

$id_admin = $_SESSION['id'];

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<body>
    <div class="sidebar" id="sidebar">
        <?php include "sidebar.php" ?>
    </div>
    <div class="main-content" id="main-content">
        <div class="header">
            <h2>User Management</h2>
            <div class="profile">
                <img src="handini.png" alt="Profile Picture">
                <span>Handini</span>
            </div>
        </div>
        <div class="registered-businesses">
            <h3>Admin</h3>
            <div class="search-bar">
                <input type="text" placeholder="Search by Name, Email" />
            </div>
            <div class="admin-table">
                <table id="adminTable">
                    <thead>
                        <tr>
                            <th> </th>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Last Login</th>
                            <!-- <th>Password</th> -->
                            <th>Histori</th>
                            <th>Tindakan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php

                        $sql = "SELECT * FROM user_management";
                        $result = mysqli_query($conn, $sql);

                        if (mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_assoc($result)) {
                        ?>
                                <tr data-id="<?php echo $row['id']; ?>">
                                    <td><input type='checkbox' /></td>
                                    <td><?php echo $row['nama_admin'] ?></td>
                                    <td><?php echo $row['email_admin'] ?></td>
                                    <td><?php echo $row['role'] ?></td>
                                    <td><?php echo $row['last_login'] ?></td>
                                    <!-- <td><?php echo $row['password'] ?></td> -->
                                    <td><?php echo $row['histori_admin'] ?></td>
                                    <td class='aksi'>
                                        <button type='button' onclick="openEditModal(<?php echo $row['id'] ?>)" class='edit-button'><i class='fa-regular fa-pen-to-square'></i></button>
                                        <button type='button' class='delete-button' onclick="deleteAdmin(<?php echo $row['id'] ?>)"><i class='fa-solid fa-trash'></i></button>
                                    </td>
                                </tr>
                                <div id="editModal<?php echo $row['id'] ?>" class="modal">
                                    <div class="modal-content">
                                        <span onclick="document.getElementById('editModal<?php echo $d['umkm_id'] ?>').style.display='none'" class="close" title="Close Modal">&times;</span>
                                        <h2>Edit Admin</h2>
                                        <hr />
                                        <form id="editAdminForm<?php echo $row['id'] ?>" method="post" action="edit_admin.php">
                                            <input type="hidden" name="id" value="<?php echo $row['id'] ?>">
                                            <div class="form-group">
                                                <label for="nama_admin">Nama Lengkap</label>
                                                <input type="text" name="nama_admin" placeholder="Nama Lengkap" value="<?php echo $row['nama_admin'] ?>" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="email_admin">Email</label>
                                                <input type="email" name="email_admin" placeholder="Email" value="<?php echo $row['email_admin'] ?>" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="role">Role</label>
                                                <select name="role" required>
                                                    <option value="admin" <?php echo ($row['role'] == 'admin') ? 'selected' : '' ?>>Admin</option>
                                                    <option value="super-admin" <?php echo ($row['role'] == 'super-admin') ? 'selected' : '' ?>>Super Admin</option>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label for="password">Password</label>
                                                <input type="text" name="password" placeholder="Password" value="<?php echo $row['password'] ?>" required>
                                            </div>
                                            <div class="button-container">
                                                <button type="button" class="button cancelbtn" onclick="closeEditModal(<?php echo $row['id'] ?>)">Cancel</button>
                                                <button type="submit" class="editSubmitBtn">Submit</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                        <?php
                            }
                        } else {
                            echo "<tr><td colspan='8'>No data found</td></tr>";
                        }

                        mysqli_close($conn);
                        ?>
                    </tbody>
                </table>
            </div>
            <div class="clearfix">
                <button class="button btn" onclick="openAddNewAdminModal()">Add New</button>
            </div>
        </div>
    </div>

    <!-- Add New Admin Modal -->
    <div id="addNewAdminModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeAddNewAdminModal()">&times;</span>
            <h2>Add New Admin</h2>
            <form id="addAdminForm" action="add_admin.php" method="post">
                <input type="hidden" id="id_admin" name="id_admin" value="<?php echo $id_admin ?>">
                <input type="text" id="fullname" name="fullname" placeholder="Nama Lengkap" required>
                <input type="email" id="email" name="email" placeholder="Email" required>
                <input type="password" id="password" name="password" placeholder="Password" required>
                <select id="role" name="role">
                    <option value="admin">Admin</option>
                    <option value="super-admin">Super Admin</option>
                </select>
                <button type="submit" id="submitBtn">Submit</button>
            </form>
        </div>
    </div>

    <script>
        // Modal functionality
        function openAddNewAdminModal() {
            document.getElementById('addNewAdminModal').style.display = 'block';
        }

        function closeAddNewAdminModal() {
            document.getElementById('addNewAdminModal').style.display = 'none';
        }

        function openEditModal(id) {
            document.getElementById('editModal' + id).style.display = 'block';
        }

        function closeEditModal(id) {
            document.getElementById('editModal' + id).style.display = 'none';
        }

        function deleteAdmin(id) {
            if (confirm("Apakah Anda yakin ingin menghapus admin ini?")) {
                window.location.href = "delete_admin.php?id=" + id;
            }
        }

        function closeEditModal(id) {
            document.getElementById('editModal' + id).style.display = 'none';
        }

        window.onclick = function(event) {
            var addModal = document.getElementById('addNewAdminModal');
            var editModals = document.querySelectorAll('.modal');

            if (event.target == addModal) {
                addModal.style.display = 'none';
            }

            editModals.forEach(function(modal) {
                if (event.target == modal) {
                    modal.style.display = 'none';
                }
            });
        }
    </script>
</body>

</html>