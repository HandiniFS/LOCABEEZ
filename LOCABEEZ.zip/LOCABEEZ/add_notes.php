<?php
include 'sql_connect.php';
session_start();

$pengguna_id = $_POST['pengguna_id'];
$nama_kegiatan = $_POST['nama_kegiatan'];
$time = $_POST['time'];
$keterangan = $_POST['keterangan'];
$today = date('d-m-Y  H:i:s');
$id_admin = $_SESSION['id'];

mysqli_query($conn, "INSERT INTO notes(notes_id, pengguna_id, nama_kegiatan, time, keterangan, done) VALUES ('','$pengguna_id','$nama_kegiatan','$time','$keterangan','0')");

$update_query = "UPDATE user_management SET histori_admin ='Menambahkan data notes baru pada $today' WHERE id=$id_admin";
if (mysqli_query($conn, $update_query)) {

    $sql_log = "INSERT INTO log_admin (admin_id, action, timestamp)
        VALUES ('$id_admin', 'Menambahkan notes baru', '$today')";
    if (mysqli_query($conn, $sql_log)) {
        header('Location: notes.php?id=4');
        exit;
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
