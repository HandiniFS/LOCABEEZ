<?php
include 'sql_connect.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $judul = $_POST['judul1'];
    $deskripsi = $_POST['deskripsi1'];
    $link = $_POST['link1'];
    $topik = $_POST['topik1'];
    $tanggal = $_POST['tanggal1'];
    $modul_id = $_POST['modul_id1'];
    $id_admin = $_SESSION['id'];
    $today = date('d-m-Y  H:i:s');

    $sql = "UPDATE modul 
    SET judul = '$judul', deskripsi = '$deskripsi', link = '$link', topik = '$topik', tanggal = '$tanggal'
    WHERE modul_id = '$modul_id'";

    if (mysqli_query($conn, $sql)) {
        $update_query = "UPDATE user_management SET histori_admin ='Mengedit data modul: $nama_admin pada $today' WHERE id=$id_admin";
        if (mysqli_query($conn, $update_query)) {

            $sql_log = "INSERT INTO log_admin (admin_id, action, timestamp)
        VALUES ('$id_admin', 'Mengedit data modul', '$today')";
            if (mysqli_query($conn, $sql_log)) {
                header('Location: UMKMDevelopment.php?id=2');
                exit;
            } else {
                echo "Error: " . $sql . "<br>" . mysqli_error($conn);
            }
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}

mysqli_close($conn);
