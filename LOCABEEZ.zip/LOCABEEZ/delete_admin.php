<?php
include 'sql_connect.php';
session_start();

$adminId = mysqli_real_escape_string($conn, $_GET['id']);
$id_admin = $_SESSION['id'];
$today = date('d-m-Y  H:i:s');

if (empty($adminId)) {
    http_response_code(400); // Bad Request
    echo json_encode(array("message" => "ID admin tidak ditemukan."));
    exit;
}

// Hapus data terkait di tabel log_admin terlebih dahulu
$sqlDeleteLog = "DELETE FROM log_admin WHERE admin_id = '$adminId'";

if (!mysqli_query($conn, $sqlDeleteLog)) {
    http_response_code(500);
    echo json_encode(array("message" => "Gagal menghapus log admin terkait: " . mysqli_error($conn)));
    exit;
}

// Hapus admin dari tabel user_management
$sqlDelete = "DELETE FROM user_management WHERE id = '$adminId'";

if (mysqli_query($conn, $sqlDelete)) {
    $sqlUpdateHistory = "UPDATE user_management 
                         SET histori_admin = 'Menghapus admin dengan ID: $adminId'
                         WHERE id = $id_admin";
    if (!mysqli_query($conn, $sqlUpdateHistory)) {
        http_response_code(500);
        echo json_encode(array("message" => "Gagal memperbarui histori admin: " . mysqli_error($conn)));
        exit;
    }

    $sql_log = "INSERT INTO log_admin (admin_id, action, timestamp)
        VALUES ('$id_admin', 'Menghapus data admin', '$today')";
    if (!mysqli_query($conn, $sql_log)) {
        http_response_code(500);
        echo json_encode(array("message" => "Gagal mencatat log admin: " . mysqli_error($conn)));
        exit;
    }

    http_response_code(200);
    echo json_encode(array("message" => "Admin berhasil dihapus."));
    header("Location: UserManagement.php?id=7");
} else {
    http_response_code(500);
    echo json_encode(array("message" => "Gagal menghapus admin: " . mysqli_error($conn)));
    header("Location: UserManagement.php?id=7");
}

mysqli_close($conn);
?>
