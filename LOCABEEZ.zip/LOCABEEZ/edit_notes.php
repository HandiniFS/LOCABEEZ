<?php
include 'sql_connect.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id_notes1'];
    $nama_kegiatan = $_POST['nama_kegiatan1'];
    $time = $_POST['time1'];
    $keterangan = $_POST['keterangan1'];
    $done = $_POST['done1'];
    $id_admin = $_SESSION['id'];
    $today = date('d-m-Y  H:i:s');

    $sql = "UPDATE notes 
    SET nama_kegiatan = '$nama_kegiatan', time = '$time', keterangan = '$keterangan', done = '$done'
    WHERE notes_id = '$id'";

    if (mysqli_query($conn, $sql)) {
        $update_query = "UPDATE user_management SET histori_admin ='Mengedit data notes pada $today' WHERE id=$id_admin";
        if (mysqli_query($conn, $update_query)) {
            $sql_log = "INSERT INTO log_admin (admin_id, action, timestamp)
        VALUES ('$id_admin', 'Mengedit data notes', '$today')";
            if (mysqli_query($conn, $sql_log)) {
                header('Location: Notes.php?id=4');
                exit;
            } else {
                echo "Error: " . $sql . "<br>" . mysqli_error($conn);
            }
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}

mysqli_close($conn);
