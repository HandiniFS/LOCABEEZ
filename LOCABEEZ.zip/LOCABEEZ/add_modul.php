<?php
include 'sql_connect.php';
session_start();

// Tangkap data dari formulir
$judul = mysqli_real_escape_string($conn, $_POST['judul']);
$deskripsi = mysqli_real_escape_string($conn, $_POST['deskripsi']);
$link = mysqli_real_escape_string($conn, $_POST['link']);
$topik = mysqli_real_escape_string($conn, $_POST['topik']);
$tanggal = mysqli_real_escape_string($conn, $_POST['tanggal']);
$id_admin = $_SESSION['id'];
$today = date('d-m-Y  H:i:s');

$sql = "INSERT INTO modul (judul, deskripsi, link, topik, tanggal)
        VALUES ('$judul', '$deskripsi', '$link', '$topik', '$tanggal')";

if (mysqli_query($conn, $sql)) {
    $update_query = "UPDATE user_management SET histori_admin ='Menambahkan modul baru pada $today' WHERE id=$id_admin";
    if (mysqli_query($conn, $update_query)) {
        $sql_log = "INSERT INTO log_admin (admin_id, action, timestamp)
        VALUES ('$id_admin', 'Menambahkan modul baru', '$today')";
        if (mysqli_query($conn, $sql_log)) {
            header('Location: UMKMDevelopment.php?id=3');
            exit;
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
