<?php
// Memuat file autoload Composer
require_once __DIR__ . '/vendor/autoload.php';

// Menggunakan kelas Groq dari namespace LucianoTonet\GroqPHP
use LucianoTonet\GroqPHP\Groq;

try {
    // Membuat instance dari kelas Groq dengan API key
    $groq = new Groq('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');

    // Membuat chat completion
    $chatCompletion = $groq->chat()->completions()->create([
        'model'    => 'mixtral-8x7b-32768',
        'messages' => [
            [
                'role'    => 'user',
                'content' => 'presiden rusia saat ini'
            ],
        ]
    ]);

    // Menampilkan hasil
    echo $chatCompletion['choices'][0]['message']['content'];

} catch (Exception $e) {
    echo 'Terjadi kesalahan: ',  $e->getMessage(), "\n";
}
?>
