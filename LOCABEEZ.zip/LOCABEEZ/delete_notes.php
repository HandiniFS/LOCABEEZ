<?php
include 'sql_connect.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['notes_id'])) {
        $notes_id = intval($_POST['notes_id']);
        $today = date('d-m-Y  H:i:s');
        $id_admin = $_SESSION['id'];

        $notes_id = mysqli_real_escape_string($conn, $notes_id);

        $query = "DELETE FROM notes WHERE notes_id = $notes_id";

        if (mysqli_query($conn, $query)) {
            $update_query = "UPDATE user_management SET histori_admin ='Menghapus data Notes pada $today' WHERE id=$id_admin";
            if (mysqli_query($conn, $update_query)) {

                $sql_log = "INSERT INTO log_admin (admin_id, action, timestamp)
        VALUES ('$id_admin', 'Menghapus data notes', '$today')";
                if (mysqli_query($conn, $sql_log)) {
                    header('Location: notes.php?id=4');
                    exit;
                } else {
                    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
                }
            } else {
                echo "Error: " . $sql . "<br>" . mysqli_error($conn);
            }
        } else {
            echo "Gagal menghapus catatan: " . mysqli_error($conn);
        }
    } else {
        echo "ID catatan tidak ditemukan.";
    }
} else {
    echo "Metode request tidak valid.";
}
