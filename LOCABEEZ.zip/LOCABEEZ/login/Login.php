<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login</title>
  <link rel="stylesheet" href="Login.css" />
</head>

<body>
  <main>
    <div class="box">
      <div class="inner-box">
        <div class="forms-wrap">
          <form method="POST" action="cek_login.php" autocomplete="off" class="sign-in-form">
            <div class="logo">
              <img src="../Grafik.png" />
              <div class="logo">
                <h1><span class="loca">LOCA</span><span class="beez">BEEZ</span></h1>
              </div>
            </div>
            <?php
            if (isset($_GET['pesan'])) {
              if ($_GET['pesan'] == "gagal") {
                echo "Login gagal! username dan password salah!";
              } else if ($_GET['pesan'] == "logout") {
                echo "Anda telah berhasil logout";
              } else if ($_GET['pesan'] == "belum_login") {
                echo "Anda harus login untuk mengakses halaman admin";
              }
            }
            ?>
            <div class="heading">
              <h2>Silahkan Login</h2>
            </div>

            <div class="actual-form">
              <div class="input-wrap">
                <input type="email" name="email" class="input-field" autocomplete="off" required />
                <label>Email</label>
              </div>

              <div class="input-wrap">
                <input type="password" name="password" class="input-field" autocomplete="off" required />
                <label>Kata Sandi</label>
              </div>

              <input type="submit" value="Masuk" class="sign-btn" />

              <?php if (isset($error)) {
                echo "<p style='color: red;'>$error</p>";
              } ?>
            </div>
          </form>
        </div>

        <div class="carousel">
          <div class="images-wrapper">
            <img src="image1.jpg" class="image img-1 show" alt="" />
            <img src="image2.jpg" class="image img-2" alt="" />
            <img src="image3.jpg" class="image img-3" alt="" />
          </div>

          <div class="text-slider">
            <div class="text-wrap">
              <div class="text-group">
                <h3>Lestarikan UMKM dengan meramaikannya!</h3>
                <h3>Barang lengkap dan murah!</h3>
                <h3>Jelajahi semua UMKM di Sleman!</h3>
              </div>
            </div>

            <div class="bullets">
              <span class="active" data-value="1"></span>
              <span data-value="2"></span>
              <span data-value="3"></span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>

  <!-- Javascript file -->
  <script src="login.js"></script>
</body>

</html>