<?php
session_start();

include '../sql_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $query = "SELECT * FROM user_management WHERE email_admin=? AND password=?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ss", $email, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $admin = $result->fetch_assoc();

        $_SESSION['email'] = $email;
        $_SESSION['role'] = $admin['role'];
        $_SESSION['status'] = "login";
        $_SESSION['id'] = $admin['id'];

        $admin_id = $admin['id'];

        $update_query = "UPDATE user_management SET last_login=NOW() WHERE id=?";
        $update_stmt = $conn->prepare($update_query);
        $update_stmt->bind_param("i", $admin_id);
        $update_stmt->execute();

        header("Location: ../dashboard.php?id=1");
        exit();
    } else {
        header("Location: login.php?pesan=gagal");
        exit();
    }

    $stmt->close();
    $update_stmt->close();
    $conn->close();
}
