<?php
include 'sql_connect.php';

// Tangkap data dari formulir
$fullname = mysqli_real_escape_string($conn, $_POST['fullname']);
$email = mysqli_real_escape_string($conn, $_POST['email']);
$password = mysqli_real_escape_string($conn, $_POST['password']);
$role = mysqli_real_escape_string($conn, $_POST['role']);
$id_admin = mysqli_real_escape_string($conn, $_POST['id_admin']);
$today = date('d-m-Y  H:i:s');

$sql = "INSERT INTO user_management (nama_admin, email_admin, password, role, histori_admin)
        VALUES ('$fullname', '$email', '$password', '$role', 'Ditambahkan sebagai admin baru pada : $today')";

if (mysqli_query($conn, $sql)) {
    $update_query = "UPDATE user_management SET histori_admin ='Menambahkan admin baru: $fullname pada $today' WHERE id=$id_admin";
    if (mysqli_query($conn, $update_query)) {
        $sql_log = "INSERT INTO log_admin (admin_id, action, timestamp)
        VALUES ('$id_admin', 'Menambahkan admin baru', '$today')";
        if (mysqli_query($conn, $sql_log)) {
            header('Location: UserManagement.php?id=7');
            exit;
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
