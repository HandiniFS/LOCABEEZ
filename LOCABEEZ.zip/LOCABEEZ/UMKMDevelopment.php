<?php include 'sql_connect.php';
session_start();
if ($_SESSION['status'] != "login") {
  header("location:login/login.php?pesan=belum_login");
}

$id_admin = $_SESSION['id'];

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>UMKM Development</title>
  <link rel="stylesheet" href="styles.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
</head>

<body>
  <div class="sidebar">
    <?php include "sidebar.php" ?>
  </div>
  <div class="main-content">
    <header>
      <div class="header">
        <h2>UMKM Development</h2>
        <div class="search-profile">
          <input type="text" placeholder="Search here..." />
        </div>
        <div class="profile">
          <img src="handini.png" alt="Profile Picture" />
          <span>Handini</span>
        </div>
      </div>
    </header>

    <h1 class="main-title">Learning Module Studio</h1>
    <div class="card post">
      <button class="tablink" onclick="openPage('Module', this, 'module')" id="module">
        Module
      </button>
      <button class="tablink" onclick="openPage('Analytic', this, 'analytic')" id="analytic">
        Analytic
      </button>

      <div id="Module" class="tabcontent">
        <table>
          <tr>
            <td><input type="checkbox" /></td>
            <th colspan="2">Video Module</th>
            <th>Topic</th>
            <th>Tanggal</th>
            <th>View</th>
            <th>Likes</th>
            <th class="aksi">Aksi</th>
          </tr>
          <?php
          $data = mysqli_query($conn, "select * from modul");
          while ($d = mysqli_fetch_array($data)) {
            $link = substr($d['link'], 17);
          ?>
            <tr>
              <td><input type="checkbox" /></td>
              <td>
                <?php
                // $youtubeid = "uSapTOwI_L0?si=PuEU3o6DoZBiMhTm";
                // $url = "https://www.youtube.com/oembed?url=http://www.youtube.com/watch?v=$youtubeid&format=json";
                // $curl = curl_init();
                // curl_setopt($curl, CURLOPT_URL, $url);
                // curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
                // curl_setopt($curl, CURLOPT_TIMEOUT, 20);
                // $result = curl_exec($curl);

                // $dt = json_decode($result, true);
                // $youtubetitle = $dt['title'];
                ?>
                <iframe width="200" height="150" src="https://www.youtube.com/embed/<?php echo $link ?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
              </td>
              <td>
                <p><?php echo $d['judul'] ?></p>
                <p><?php echo $d['deskripsi'] ?></p>
              </td>
              <td><?php echo $d['topik'] ?></td>
              <td><?php echo $d['tanggal'] ?></td>
              <td><?php echo $d['views'] ?></td>
              <td><?php echo $d['likes'] ?></td>
              <td>
                <button onclick="document.getElementById('edit_modul<?php echo $d['modul_id'] ?>').style.display='block'" class="edit-button"><i class="fa-regular fa-pen-to-square"></i></button>
                <button class="delete-button" onclick="deleteModul(<?php echo $d['modul_id'] ?>)"><i class="fa-solid fa-trash"></i></button>
              </td>
            </tr>

          <?php } ?>
        </table>

        <div class="clearfix">
          <button class="button btn" onclick="document.getElementById('add_modul').style.display='block'">
            Add Modul
          </button>
        </div>
        <?php
        $data = mysqli_query($conn, "select * from modul");
        while ($d = mysqli_fetch_array($data)) {
        ?>
          <div id="edit_modul<?php echo $d['modul_id'] ?>" class="modal">
            <span onclick="document.getElementById('edit_modul<?php echo $d['modul_id'] ?>').style.display='none'" class="close" title="Close Modal">&times;</span>
            <form method="post" class="modal-content" action="edit_modul.php">
              <h2>Edit Notes</h2>
              <hr />
              <input type="hidden" name="modul_id1" value="<?php echo $d['modul_id'] ?>" />
              <div class="form-group">
                <label for="judul1"><b>Judul Modul</b></label>
                <input type="text" name="judul1" value="<?php echo $d['judul'] ?>" required />
              </div>
              <div class="form-group">
                <label for="deskripsi1"><b>Deskripsi</b></label>
                <textarea rows="5" type="text" name="deskripsi1"><?php echo $d['deskripsi'] ?></textarea>
              </div>
              <div class="form-group">
                <label for="link1"><b>Link Youtube</b></label>
                <input type="text" name="link1" value="<?php echo $d['link'] ?>" required />
              </div>
              <div class="form-group">
                <label for="topik1"><b>Topik</b></label>
                <input type="text" name="topik1" value="<?php echo $d['topik'] ?>" required />
              </div>
              <div class="form-group">
                <label for="tanggal1"><b>Tanggal</b></label>
                <input type="date" name="tanggal1" value="<?php echo $d['tanggal'] ?>" required />
              </div>
              <div class="clearfix">
                <button onclick="document.getElementById('edit_modul<?php echo $d['modul_id'] ?>').style.display='none'" class="button cancelbtn">
                  Cancel
                </button>
                <button type="submit" class="button signupbtn">Edit</button>
              </div>
            </form>
          </div>
        <?php } ?>
        <div id="add_modul" class="modal">
          <span onclick="document.getElementById('add_modul').style.display='none'" class="close" title="Close Modal">&times;</span>
          <form method="post" class="modal-content" action="add_modul.php">
            <h2>Add Modul</h2>
            <hr />
            <div class="form-group">
              <label for="judul"><b>Judul Modul</b></label>
              <input type="text" name="judul" required />
            </div>
            <div class="form-group">
              <label for="deskripsi"><b>Deskripsi</b></label>
              <textarea rows="5" type="text" name="deskripsi"></textarea>
            </div>
            <div class="form-group">
              <label for="link"><b>Link Youtube</b></label>
              <input type="text" name="link" required />
            </div>
            <div class="form-group">
              <label for="topik"><b>Topik</b></label>
              <input type="text" name="topik" required />
            </div>
            <div class="form-group">
              <label for="tanggal"><b>Tanggal</b></label>
              <input type="date" name="tanggal" required />
            </div>
            <div class="clearfix">
              <button type="button" onclick="document.getElementById('add_notes').style.display='none'" class="button cancelbtn">
                Cancel
              </button>
              <button type="submit" class="button signupbtn">Add</button>
            </div>
          </form>
        </div>
      </div>

      <div id="Analytic" class="tabcontent">
        <h3>Analytic</h3>
        <div class="charts">
          <div class="card chart-card">
            <h3>Popular Training Topics</h3>
            <canvas id="popularTrainingChart"></canvas>
          </div>
          <div class="card chart-card">
            <h3>Viewers report</h3>
            <canvas id="trainingParticipationChart"></canvas>
          </div>
        </div>
      </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="scripts.js"></script>
    <script>
      function openPage(pageName, elmnt, idPage) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
          tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablink");
        for (i = 0; i < tablinks.length; i++) {
          tablinks[i].style.backgroundColor = "";
          tablinks[i].style.borderBottomColor = "#ffffff";
          tablinks[i].style.borderBottom = "none";
        }
        document.getElementById(pageName).style.display = "block";
        document.getElementById(idPage).style.borderBottom = "solid";
        document.getElementById(idPage).style.borderBottomColor = "#FF005C";
        elmnt.style.borderBottomWidth = "5px";
      }

      // Get the element with id="defaultOpen" and click on it
      document.getElementById("module").click();

      var modal = document.getElementById("add_modul");
      window.onclick = function(event) {
        if (event.target == modal) {
          modal.style.display = "none";
        }
      };

      <?php
      $data = mysqli_query($conn, "select * from modul");
      while ($d = mysqli_fetch_array($data)) {
      ?>
        var modal_edit_<?php echo $d['modul_id']; ?> = document.getElementById("edit_modul<?php echo $d['modul_id']; ?>");
        (function(modal_edit_<?php echo $d['modul_id']; ?>) {
          window.onclick = function(event) {
            if (event.target == modal_edit_<?php echo $d['modul_id']; ?>) {
              modal_edit_<?php echo $d['modul_id']; ?>.style.display = "none";
            }
          };
        })(modal_edit_<?php echo $d['modul_id']; ?>);
      <?php } ?>

      function deleteModul(id) {
        if (confirm("Apakah Anda yakin ingin menghapus modul ini?")) {
          window.location.href = "delete_modul.php?id=" + id;
        }
      }
    </script>
  </div>
</body>

</html>