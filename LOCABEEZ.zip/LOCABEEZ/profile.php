<?php include 'sql_connect.php';
session_start();
if ($_SESSION['status'] != "login") {
  header("location:../login/login.php?pesan=belum_login");
} ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notes</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<body>
    <div class="sidebar" id="sidebar">
        <?php include "sidebar.php" ?>
    </div>
    <div class="main-content" id="main-content">
        <div class="header">
            <h2>Settings</h2>
            <div class="search-profile">
                <input type="text" placeholder="Search here...">
            </div>
            <div class="profile">
                <img src="handini.png" alt="Profile Picture">
                <span>Handini</span>
            </div>
        </div>

        <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UMKM Development</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Styling for demonstration purposes */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
        }
        .modal-content {
            background-color: white;
            padding: 20px;
            border-radius: 5px;
        }
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        .profile-picture {
            width: 100px; /* Ukuran foto profil */
            height: 100px; /* Ukuran foto profil */
            border-radius: 50%; /* Bulatkan sudut */
            object-fit: cover; /* Pastikan gambar tidak terlalu besar */
        }
    </style>
</head>
<body>
        <section class="dashboard">
            <div class="profile-container">
                <div class="user-info">
                    <div class="info-section">
                        <h3>PROFIL PENGGUNA</h3>
                        <div class="profile-card">
                            <div class="profile-header">
                                <img id="currentProfilePicture" src="public/user-images/<?=$_SESSION['user_pp']?>" alt="Profile Picture" class="profile-picture">
                            </div>
                        </div>
                        <br>
                        <p><strong>Name:</strong> <span id="name"><?=$_SESSION['nama_rs']?></span></p>
                        <br>
                        <p><strong>Email:</strong> <span id="email"><?=$_SESSION['email']?></span></p>
                        <br>
                        <p><strong>Alamat:</strong> <span id="alamat"><?=$_SESSION['alamat']?></span></p>
                        <br>
                        <p><strong>No. Telepon:</strong> <span id="noTelepon"><?=$_SESSION['no_telp']?></span></p>
                        <br>
                        <p><strong>Username:</strong> <span id="username"><?=$_SESSION['username']?></span></p>
                    </div>
                    <button class="edit-button" onclick="editProfile()">Edit</button>
                </div>
            </div>
        
            <!-- Edit Modal -->
            <div id="editModal" class="modal">
                <div class="modal-content">
                    <span class="close" onclick="closeModal()">&times;</span>
                    <h2>Edit Profile</h2>
                    <form id="editForm" action="" enctype="multipart/form-data" method="POST" onsubmit="saveProfile(event)">
                        <label for="editName">Name:</label>
                        <input type="text" id="editName" name="editName" required>
                        <label for="editEmail">Email:</label>
                        <input type="email" id="editEmail" name="editEmail" required>
                        <label for="editAlamat">Alamat:</label>
                        <input type="text" id="editAlamat" name="editAlamat">
                        <label for="editNoTelepon">No. Telepon:</label>
                        <input type="text" id="editNoTelepon" name="editNoTelepon">
                        <label for="editUsername">Username:</label>
                        <input type="text" id="editUsername" name="editUsername" required>
                        <label for="editProfilePicture">Profile Picture:</label>
                        <input type="file" id="editProfilePicture" name="editProfilePicture" accept="image/*">
                        <button type="submit">Save</button>
                    </form>
                </div>
            </div>
        </section>

        <script>
            function editProfile() {
                // Show the modal
                document.getElementById('editModal').style.display = 'flex';
            
                // Pre-fill the form with current values
                document.getElementById('editName').value = document.getElementById('name').innerText;
                document.getElementById('editEmail').value = document.getElementById('email').innerText;
                document.getElementById('editAlamat').value = document.getElementById('alamat').innerText;
                document.getElementById('editNoTelepon').value = document.getElementById('noTelepon').innerText;
                document.getElementById('editUsername').value = document.getElementById('username').innerText;
            }
            
            function closeModal() {
                // Hide the modal
                document.getElementById('editModal').style.display = 'none';
            }
            
            function saveProfile(event) {
                event.preventDefault();
            
                const newName = document.getElementById('editName').value;
                const newEmail = document.getElementById('editEmail').value;
                const newAlamat = document.getElementById('editAlamat').value;
                const newNoTelepon = document.getElementById('editNoTelepon').value;
                const newUsername = document.getElementById('editUsername').value;
            
                document.getElementById('name').innerText = newName;
                document.getElementById('email').innerText = newEmail;
                document.getElementById('alamat').innerText = newAlamat;
                document.getElementById('noTelepon').innerText = newNoTelepon;
                document.getElementById('username').innerText = newUsername;
            
                const fileInput = document.getElementById('editProfilePicture');
                if (fileInput.files && fileInput.files[0]) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        document.getElementById('currentProfilePicture').src = e.target.result;
                    }
                    reader.readAsDataURL(fileInput.files[0]);
                }
            
                // Close the modal
                closeModal();
            }
        </script>
    </div>
</body>
</html>

        </section>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="scripts.js"></script>
</body>

</html>