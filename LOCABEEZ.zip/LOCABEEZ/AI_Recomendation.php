<?php include 'sql_connect.php';
session_start();
if ($_SESSION['status'] != "login") {
    header("location:login/login.php?pesan=belum_login");
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Recommendation</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<body>
    <div class="sidebar-1" id="sidebar-1">
        <?php include "sidebar.php" ?>

    </div>

    <div class="main-content" id="main-content">
        <div class="header">
            <h2>AI Recommendation</h2>
            <div class="search-profile">
                <input type="text" placeholder="Search here...">
            </div>
            <div class="profile">
                <img src="handini.png" alt="Profile Picture">
                <span>Handini</span>
            </div>
        </div>

        <div class="chat-container">
            <div class="chat-header">
                <h2>AI Beez</h2>
            </div>
            <div class="chat-messages" id="chat-messages">
                <!-- Display chat messages here -->
                <?php
                require_once __DIR__ . '/vendor/autoload.php';

                use LucianoTonet\GroqPHP\Groq;

                function fetchUMKMData($conn)
                {
                    $sql = "SELECT umkm, bln, thn, pndptn, alamat, jnsusaha, nmpngusaha, kontak FROM pendapatan_umkm";
                    $result = $conn->query($sql);

                    $data = [];
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $data[] = $row;
                        }
                    }
                    return $data;
                }

                if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST["user_input"])) {
                    try {
                        include 'sql_connect.php';

                        $groq = new Groq('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');
                        $input = trim($_POST["user_input"]);

                        $umkmData = fetchUMKMData($conn);

                        $dataString = "Data UMKM:\n";
                        foreach ($umkmData as $data) {
                            $dataString .= "UMKM: {$data['umkm']}, Bulan: {$data['bln']}, Tahun: {$data['thn']}, Pendapatan: {$data['pndptn']}, Alamat: {$data['alamat']}, jenis: {$data['jnsusaha']}, Pemilik: {$data['nmpngusaha']}, Kontak: {$data['kontak']}\n";
                        }

                        $prompt = "Jawablah dalam bahasa Indonesia: Input Pengguna: $input\n\n$dataString";

                        $chatCompletion = $groq->chat()->completions()->create([
                            'model' => 'mixtral-8x7b-32768',
                            'messages' => [
                                [
                                    'role' => 'user',
                                    'content' => $prompt
                                ],
                            ]
                        ]);

                        echo htmlspecialchars($chatCompletion['choices'][0]['message']['content']);
                    } catch (Exception $e) {
                        if ($e->getCode() == 429) {
                            echo 'Batas permintaan tercapai. Silakan coba lagi nanti.';
                        } else {
                            echo 'Terjadi kesalahan: ' . htmlspecialchars($e->getMessage());
                        }
                    }
                    exit;
                }
                ?>

            </div>
            <form class="chat-form" method="post" onsubmit="return addMessage();">
                <input type="text" id="chat-input" name="user_input" placeholder="Type a message...">
                <button type="submit" id="send-btn">Send</button>
            </form>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="ai.js"></script>
</body>

</html>