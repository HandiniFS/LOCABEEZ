<?php
include 'sql_connect.php';
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] !== "login") {
    header("location:login/login.php?pesan=belum_login");
    exit();
}

$id_admin = $_SESSION['id'];

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notes</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<body>
    <div class="sidebar" id="sidebar">
        <?php include "sidebar.php" ?>
    </div>
    <div class="main-content" id="main-content">
        <div class="header">
            <h2>Dashboard</h2>
            <div class="search-profile">
                <input type="text" placeholder="Search here...">
            </div>
            <div class="profile">
                <img src="handini.png" alt="Profile Picture">
                <span>Handini</span>
            </div>
        </div>
        <h1 class="main-title">Things To Do</h1>
        <div class="card post">
            <table style="width: 100%">
                <tr>
                    <th style="text-align: center; width:70px">Done</th>
                    <th>Nama Kegiatan</th>
                    <th>Time</th>
                    <th style="width:500px">Keterangan</th>
                    <th style="width:120px">Aksi</th>
                </tr>
                <?php
                $data = mysqli_query($conn, "select * from notes where pengguna_id=1");
                while ($d = mysqli_fetch_array($data)) {
                ?>
                    <tr id="note-<?php echo $d['notes_id']; ?>">
                        <td style="text-align: center"><input type="checkbox" name="done" <?php if ($d['done'] == 1) {
                                                                                    echo 'checked';
                                                                                } ?> /></td>
                        <td>
                            <p><?php echo $d['nama_kegiatan'] ?></p>
                        </td>
                        <td>
                            <p><?php echo $d['time'] ?></p>
                        </td>
                        <td>
                            <p><?php echo $d['keterangan'] ?></p>
                        </td>
                        <td class="aksi">
                            <button class="edit-button" onclick="document.getElementById('edit_notes<?php echo $d['notes_id'] ?>').style.display='block'"><i class="fa-regular fa-pen-to-square"></i></button>
                            <button class="delete-button" onclick="deleteNotes(<?php echo $d['notes_id'] ?>)"><i class="fa-solid fa-trash"></i></button>
                        </td>
                    </tr>
                <?php
                }
                ?>
            </table>
            <?php
            $data = mysqli_query($conn, "select * from notes where pengguna_id=1");
            while ($d = mysqli_fetch_array($data)) {
            ?>
                <div id="edit_notes<?php echo $d['notes_id'] ?>" class="modal">
                    <span onclick="document.getElementById('edit_notes<?php echo $d['notes_id'] ?>').style.display='none'" class="close" title="Close Modal">&times;</span>
                    <form method="post" class="modal-content" action="edit_notes.php">
                        <h2>Edit Notes</h2>
                        <hr />
                        <input hidden type="checkbox" name="done1" value="<?php echo $d['done'] ?>" />
                        <input type="hidden" name="id_notes1" value="<?php echo $d['notes_id'] ?>" />
                        <div class="form-group" style="margin-top: 30px;">
                            <label for="nama_kegiatan1"><b>Nama Kegiatan</b></label>
                            <input type="text" name="nama_kegiatan1" value="<?php echo $d['nama_kegiatan'] ?>" />
                        </div>
                        <div class="form-group" style="margin-top: 30px;">
                            <label for="time1"><b>Time</b></label>
                            <input type="date" name="time1" value="<?php echo $d['time'] ?>" />
                        </div>
                        <div class="form-group" style="margin-top: 30px;">
                            <label for="keterangan1"><b>Keterangan</b></label>
                            <textarea rows="5" type="text" name="keterangan1"><?php echo $d['keterangan'] ?></textarea>
                        </div>
                        <div class="clearfix">
                            <button type="button" onclick="document.getElementById('edit_notes<?php echo $d['notes_id'] ?>').style.display='none'" class="button cancelbtn">
                                Cancel
                            </button>
                            <button type="submit" class="button signupbtn">Edit</button>
                        </div>
                    </form>
                </div>
            <?php
            }
            ?>
            <div class="clearfix">
                <button class="button btn" onclick="document.getElementById('add_notes').style.display='block'">
                    Add Notes
                </button>
            </div>
            <div id="add_notes" class="modal">
                <span onclick="document.getElementById('add_notes').style.display='none'" class="close" title="Close Modal">&times;</span>
                <form method="post" class="modal-content" action="add_notes.php">
                    <h2>Add Notes</h2>
                    <hr />
                    <input type="hidden" name="pengguna_id" value="1" />
                    <div class="form-group">
                        <label for="nama_kegiatan"><b>Nama Kegiatan</b></label>
                        <input type="text" name="nama_kegiatan" required />
                    </div>
                    <div class="form-group">
                        <label for="time"><b>Time</b></label>
                        <input type="date" name="time" required />
                    </div>
                    <div class="form-group">
                        <label for="keterangan"><b>Keterangan</b></label>
                        <textarea rows="5" type="text" name="keterangan"></textarea>
                    </div>
                    <div class="clearfix">
                        <button type="button" onclick="document.getElementById('add_notes').style.display='none'" class="button cancelbtn">
                            Cancel
                        </button>
                        <button type="submit" class="button signupbtn">Add</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="scripts.js"></script>
    <script>
        var modal = document.getElementById("add_notes");
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        };

        <?php
        $data = mysqli_query($conn, "select * from notes where pengguna_id=1");
        while ($d = mysqli_fetch_array($data)) {
        ?>
            var modal_edit_<?php echo $d['notes_id']; ?> = document.getElementById("edit_notes<?php echo $d['notes_id']; ?>");
            (function(modal_edit_<?php echo $d['notes_id']; ?>) {
                window.onclick = function(event) {
                    if (event.target == modal_edit_<?php echo $d['notes_id']; ?>) {
                        modal_edit_<?php echo $d['notes_id']; ?>.style.display = "none";
                    }
                };
            })(modal_edit_<?php echo $d['notes_id']; ?>);
        <?php } ?>

        function deleteNotes(notesId) {
            if (confirm("Apakah Anda yakin ingin menghapus catatan ini?")) {
                // Kirim request untuk menghapus catatan via AJAX
                var xhr = new XMLHttpRequest();
                xhr.open("POST", "delete_notes.php", true);
                xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                xhr.onreadystatechange = function() {
                    if (xhr.readyState == 4 && xhr.status == 200) {
                        // Remove the note row from the table
                        var noteRow = document.getElementById("note-" + notesId);
                        if (noteRow) {
                            noteRow.remove();
                        }
                    }
                };
                xhr.send("notes_id=" + notesId);
            }
        }
        $(document).ready(function() {
            $(".tombol-simpan").click(function() {
                var data = $('.form-user').serialize();
                $.ajax({
                    type: 'POST',
                    url: "edit.php",
                    data: data,
                    success: function() {
                        $('.tampildata').load("tampil.php");
                    }
                });
            });
        });
    </script>
</body>

</html>