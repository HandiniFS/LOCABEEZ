<?php
include 'sql_connect.php';
session_start();

$modul_id = mysqli_real_escape_string($conn, $_GET['id']);
$id_admin = $_SESSION['id'];
$today = date('d-m-Y  H:i:s');

if (empty($modul_id)) {
    http_response_code(400); // Bad Request
    echo json_encode(array("message" => "ID Modul tidak ditemukan."));
    exit;
}

$sqlDelete = "DELETE FROM modul WHERE modul_id = '$modul_id'";

if (mysqli_query($conn, $sqlDelete)) {
    $sqlUpdateHistory = "UPDATE user_management 
                         SET histori_admin = 'Menghapus modul dengan ID: $modul_id'
                         WHERE id = $id_admin";
    mysqli_query($conn, $sqlUpdateHistory);

    $sql_log = "INSERT INTO log_admin (admin_id, action, timestamp)
        VALUES ('$id_admin', 'Menghapus data modul', '$today')";
    mysqli_query($conn, $sql_log);

    http_response_code(200);
    echo json_encode(array("message" => "Modul berhasil dihapus."));
    header("Location: UMKMDevelopment.php?id=2");
} else {
    http_response_code(500);
    echo json_encode(array("message" => "Gagal menghapus Modul."));
    header("Location: UMKMDevelopment.php?id=2");
}

mysqli_close($conn);
